from typing import NamedTuple

import requests.exceptions

import ws_constants
import ws_utilities
from ws_sdk.web import WS
import ws_sdk.ws_errors

import os
import json
import logging
import sys

logging.basicConfig(level=logging.DEBUG,
                    stream=sys.stdout,
                    format='%(levelname)s %(asctime)s %(thread)d: %(message)s',
                    datefmt='%y-%m-%d %H:%M:%S')

ws_url = os.environ['WS_URL']
ws_token = os.environ['WS_TOKEN']
ws_user_key = os.environ['WS_USER_KEY']


if __name__ == '__main__':
    # aw_glob = "b2291d37eeb04581adb2fa2a7892b5e8eea4459eb6ca416d80adb79f7171334b" # AW-global1
    # aw_key = "91e0da33861c4a1199a89d66141b957d40ea09879ef04be8b4c9f956f7381134"
    # ao_glob = "017e5d676cd345b4baeeb25b73761542035255815bba4d29b2859dc03543de95"
    # ao_key = "e21a2c7846d84830a7d15b97323f7cea3d1ac77d99e546cb9cfdc7766c3502a9"
    # nat_glob1 = "6d4fd519271e495b86ed3f808899229341c31dbb51af4639bc9c9d293f3cb0b7"
    # nat_glob2 = "a93c40249740449ab7a49c11e20d76f6bfee13f5a5f947a9908c4ca2ca5f1941"
    # nat_key1 = "cb253f5e70764e1aaca38a8f63a46a4f78aaac7f514049b190b3933a2655bf7c"
    # nat_key2 = "6d4fd519271e495b86ed3f808899229341c31dbb51af4639bc9c9d293f3cb0b7"
    org = "16830c25fcd543a289089bb076db4babeeaa874b9e6d49fb8a4ccbf3d222d808"
    ibm_tests1_key = "f4659a08fc524061ac278203ee5807c09456b514c168446390c7c785d2f7827d"
    oz_key = "027ac61fce7640a89b69f60422fd30f31cb62f01670e4b849081b1ce6c0e2fdf"
    test_email = "whitesource.ps@gmail.com"
    # prod = "e612b6d8ecce4e62b8c298462f3d5c9bf322a06428e84170a2d868db3e11aa0f"  # GitLab
    # proj = "de37a8e8e0814477be35eb6b8f3b7c26295e5fc6346e4b649ee4ec311b3c2fdd"  # spiring-boot
    Natalya_Testing_Env = "775c486f066e41d08d93d628d6f5f1eb800b67093c3140d188e1aa57ef02a03c"
    email = "test1@test.com"
    key = "027ac61fce7640a89b69f60422fd30f31cb62f01670e4b849081b1ce6c0e2fdf"
    demo_token = '8150eebe55db4c1db351aa8c716e1741d03e213d3c25483398f7e85f5b3bd8b2'
    ws_conn_org = WS(user_key=key,
                     token=org)
    # non_vba_org = 'a27583c12aa44f73b4216fc4954d13a04a038608cada4524aaabf99923070d7e'
    # non_vba_key = '2cdc54179e9549418e8e615ccf7953f6b7f6eb66035347c18f50adff0e20dbd7'
    # non_vba_prod = '4ba305b2eb5b47438699d2b2caeb1423175bdc42c75147e08517b3b1b37179bf'
    #
    # non_vba_conn = WS(user_key=non_vba_key, token=non_vba_org)
    # t3 = non_vba_conn.get_ignored_alerts(report=True, token=non_vba_prod)

    # t1 = ws_conn_org.get_groups()
    # t2 = ws_conn_org.get_groups()
    # t3 = ws_conn_org.get_groups()
    # t1 = ws_conn_org.get_ignored_alerts(token=demo_token)
    # t2 = ws_conn_org.get_ignored_alerts(token=demo_token, report=True)
    # ws_conn_org.assign_user_to_group(email, ws_constants.RoleTypes.P_ALERT_RECEIVERS)


    # t = ws_utilities.get_package_managers_by_language('python')
    # t = ws_utilities.get_package_managers_by_language('NOT')

    # ws_conn_global = WS(url=ws_url,
    #                     user_key=oz_key,
    #                     token=nat_glob2,
    #                     token_type=ws_constants.GLOBAL)

    # t1 = ws_conn_global.get_scopes(scope_type=ws_constants.PRODUCT, name='My Product')
    # t2 = ws_conn_global.get_organizations()

    # ws_conn_proj = WS(url=ws_url,
    #                   user_key=ws_user_key,
    #                   token=proj,
    #                   token_type=ws_constants.PROJECT)
    #
    # ws_conn_prod = WS(url=ws_url,
    #                   user_key=ws_user_key,
    #                   token=prod,
    #                   token_type=ws_constants.PRODUCT)
    #
    ws_conn_org = WS(url=ws_url,
                     user_key=ws_user_key,
                     token=org)

    # ret = ws_conn_org.delete_user(test_email)
    # ws_conn_org.assign_user_to_group(user_email='test@test.com', group_name='grp1')
    # ws_conn_org.create_group(name='grp1')
    # assignments = ws_conn_org.get_user_group_assignments(entity_type=ws_constants.GROUPS)
    # ws_conn_org.create_user(name='srv_test2', is_service=True)
    # groups1 = ws_conn_org.get_groups(user_name='No Name')
    # groups2 = ws_conn_org.get_groups()
    # users = ws_conn_org.get_users()
    # ws_conn_org.assign_to_scope(role_type=ws_constants.RoleTypes.ADMIN)
    ws_conn_org.assign_to_scope(role_type=ws_constants.RoleTypes.P_DEFAULT_APPROVERS,
                                email=[test_email, test_email],
                                # group="grp1",
                                token='ede07418793f4ff690e92b18a45445e154dac41654d0478bb7a41d07af3eea9e')
    # ws_conn_org.assign_to_scope(role_type=ws_constants.RoleTypes.P_MEMBERSHIP, group="grp1", token='ede07418793f4ff690e92b18a45445e154dac41654d0478bb7a41d07af3eea9e')

    # ws_conn_org.create_user(name='user_test1', email="t@t.com", inviter_email="oz.tamari@whitesourcesoftware.com")

    # o_pol = ws_conn_org.get_policies()
    # pd_pol = ws_conn_prod.get_policies()
    # pj_pol = ws_conn_proj.get_policies()


    # t = ws_utilities.get_all_req_schemas(ws_conn_org)
    # with open(ws_utilities.get_all_req_schemas.__name__ + ".json", 'w') as fp:
    #     fp.write(json.dumps(t))
    # t = ws_conn_org.set_lib_notice(lib_uuid='5baeae5e-99c0-42fb-aec8-fc5fed4c4f03', text='text1') # lib: servletapi-2.4.public_draft.jar
    # t = ws_conn_org.set_lib_notice(lib_uuid='3bf1d98b-17ed-49db-91cf-75193eb347f7', text={"k1": "v1", "k2": "v2"}) # lib: avalon-framework-4.1.3.jar
    # lib_notice = ws_conn_org.get_lib_notice(product_token='dbf3131274864d2aaa6564cd421ec5aa10cc0eda345647dcae1bf06fdc68ac80')

    # inv = ws_conn_org.get_inventory(token='dbf3131274864d2aaa6564cd421ec5aa10cc0eda345647dcae1bf06fdc68ac80') # Demo Product
    # inv_h = ws_conn_org.get_inventory(token='dbf3131274864d2aaa6564cd421ec5aa10cc0eda345647dcae1bf06fdc68ac80', with_dependencies=True)  # Demo Product
    # t = ws_utilities.get_all_req_schemas(ws_conn_org)
    # t = ws_utilities.break_filename('jaxb-api-2.3.1.jar')
    # print(t)
    # t = ws_conn_org.get_vulnerabilities_per_lib(token='dbf3131274864d2aaa6564cd421ec5aa10cc0eda345647dcae1bf06fdc68ac80')
    # t = ws_conn_proj.get_inventory(with_dependencies=True)
    # t = ws_conn_proj.get_libraries(search_value="DDDF")

    # t = ws_conn_org.get_scopes()
    # t = ws_utilities.get_report_types()
    # t = ws_conn_org.get_due_diligence(token=proj)
    # t = ws_conn_org.get_due_diligence("report_bin_type")
    # t = ws_conn_org.get_alerts()
    # f = ws_conn_org.report_types['get_bugs']
    # r = 'get_bugs' in ws_conn_org.report_types
    # rt = ws_conn_org.report_types
    # raise ws_sdk.ws_errors.MissingTokenError("TOKEN")
    # t = ws_conn_prod.get_name()
    # t = ws_conn_org.get_tags()  # On himself organization
    # t = ws_conn_org.get_tags(token=proj)  # on project
    # t = ws_conn_org.get_tags(token=prod)  # on product
    #
    # t = ws_conn_prod.get_tags()                                                                         # On himself product
    # t = ws_conn_prod.get_tags(token=proj) # on project

    # t = ws_conn.get_inventory()
    # t = ws_conn.get_users()
    # t = ws_conn.get_vulnerabilities_per_lib()
    # t = ws_conn.get_assignments()
    # t = ws_conn.get_tokens_from_name("xxe - v8.1.0")
    # t = ws_conn_org.get_tags()
    # req_schema_list = ws_utilities.get_all_req_schemas(c_org)
    # prod_scopes = ws_conn_prod.get_scopes()
    # org_scopes = ws_conn_org.get_scopes()
    # t = ws_conn_org.get_library_location(token="ede07418793f4ff690e92b18a45445e154dac41654d0478bb7a41d07af3eea9e")
    # org_scopes = ws_conn_org.get_scopes(scope_type=ws_constants.PRODUCT)
    #
    # org_scopes = ws_conn_org.get_scopes(scope_type=ws_constants.PROJECT)
    #
    # org_scopes = ws_conn_org.get_scopes(token="ede07418793f4ff690e92b18a45445e154dac41654d0478bb7a41d07af3eea9e")
    #
    # org_scopes = ws_conn_org.get_scopes(name="test1")
    # print(json.dumps(req_schema_list))
    # method_list = [func for func in dir(WS) if callable(getattr(WS, func)) and not func.startswith("__")]

    # method_list = [func for func in dir(WS) if callable(getattr(WS, func)) and func.startswith("get_")]
    #
    # for method_name in method_list:
    #     print(f"Method: {method_name}")
    #     method = getattr(WS, method_name)
    #     try:
    #         ret = method(ws_conn)
    #         print(ret)
    #     except Exception as e:
    #         print(e)

    print("Done")
